from django.contrib import admin
from .models import Image_data

# Register your models here.

admin.site.register(Image_data)
